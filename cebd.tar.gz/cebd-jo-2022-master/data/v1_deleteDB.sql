-- TODO 1.3a : Détruire les tables manquantes et modifier celles ci-dessous
DROP TABLE IF EXISTS LesEpreuves;
DROP TABLE IF EXISTS LesSportifsEQ;
DROP TABLE IF EXISTS LesInscriptions;
DROP TABLE IF EXISTS LesResultats;
-- TODO 3.3 : pensez à détruire vos triggers !
